-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: ordermodule
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assigned_orders`
--

DROP TABLE IF EXISTS `assigned_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assigned_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orders_id` varchar(50) DEFAULT NULL,
  `expert_id` int DEFAULT NULL,
  `assigned_date` date DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `no_of_words` varchar(50) DEFAULT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `assigned_expert` int DEFAULT NULL,
  `assigned_expert_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigned_orders`
--

LOCK TABLES `assigned_orders` WRITE;
/*!40000 ALTER TABLE `assigned_orders` DISABLE KEYS */;
INSERT INTO `assigned_orders` VALUES (29,'001',45,'2024-04-05','2024-04-05','1000',NULL,NULL,NULL,NULL),(32,'002',46,'2024-04-26','2024-04-30','',NULL,NULL,45,'2024-05-01'),(33,'new-001',46,'2024-05-04','2024-05-25','1000',NULL,NULL,NULL,NULL),(34,'Test-001',46,'2024-05-04','2024-05-04','1000',NULL,NULL,NULL,NULL),(35,'Test-004',46,'2024-05-04','2024-05-31','1000',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `assigned_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `attachment_id` int NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `working_hours` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_attendance_1_idx` (`employee_id`),
  CONSTRAINT `fk_attendance_1` FOREIGN KEY (`employee_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget`
--

DROP TABLE IF EXISTS `budget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budget` (
  `budget_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `order_price` int NOT NULL,
  `amount_paid` int DEFAULT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mode_of_payment` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `currency` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`budget_id`),
  KEY `fk_cleint_id_2` (`client_id`),
  CONSTRAINT `fk_cleint_id_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget`
--

LOCK TABLES `budget` WRITE;
/*!40000 ALTER TABLE `budget` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `Client_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Client_contact` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Client_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Client_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `University` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Business_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Student_login` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Student_password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (56,'Sandeep Rani','+1 ','sandeep4456r@gmail.com','student','portsmouth',NULL,'sandeep4456r@gmail.com',''),(57,'Rajdeep kaur','+44 7341 700443','raajg0602@gmail.com','student','portsmouth',NULL,'raajg0602@gmail.com',''),(58,'AKSHITA PALIWAL','','paliwalakshita@gmail.com','student','KINGSTON UNIVERSITY LONDON',NULL,'paliwalakshita@gmail.com',''),(59,'Shaik Akheel','+44 7867 104449','shaikakheel444sa@gmail.com','student','University of Greenwich',NULL,'shaikakheel444sa@gmail.com',''),(60,'Ram singh ','','ram28102020@gmail.com','student','(BCU)',NULL,'ram28102020@gmail.com',''),(61,'Shweta sharma','','shwetasharma230141@gmail.com','student','london metropolitan University UK',NULL,'shwetasharma230141@gmail.com',''),(62,'Naveen(jassey wong)','+91 99967-09801','hndassignmenthelpdesk@gmail.com','vendor',NULL,'jassey wong',NULL,NULL),(63,'PRIYA','','priyaa16042003@gmail.com','student','De montFort',NULL,'priyaa16042003@gmail.com',''),(64,'Ajay Gupta','+91 62642-92136','theassignmenthelpaustralia@gmail.com','vendor',NULL,'Haryana assignment Help',NULL,NULL),(65,'Manmeet Kaur Shah','+91 98769-40833','manmeetkourshah@gmail.com','vendor',NULL,'Wake County',NULL,NULL),(66,'RahulRamesh Reshma Reference UK','+1 ','rahul1995ramesh31@gmail.com','student','Leeds Beckett University',NULL,'rahul1995ramesh31@gmail.com',''),(67,'SwanshdeepChauhan','','swanshdeepchauhan@gmail.com','student','University of Greenwich',NULL,'swanshdeepchauhan@gmail.com',''),(68,'Benetjohn','','benetjohn6@gmail.com','student','Nottingham Trent University',NULL,'benetjohn6@gmail.com',''),(69,'Nikhilacleetus','','emmanik345@gmail.com','student','London metropolitan university',NULL,'emmanik345@gmail.com',''),(70,'Aakash,Umashankar','','adhiaakash261@gmail.com','student','Ravensbourne university london',NULL,'adhiaakash261@gmail.com',''),(71,'MohitIssar','+44 7407 087319','issar92@gmail.com','student','Beckett university london',NULL,'issar92@gmail.com',''),(72,'shyamjith','','shyam143balan@gmail.com','student','roehampton university london',NULL,'shyam143balan@gmail.com',''),(73,'Harpreetsingh,','','harpreetsingh11200@gmail.com','student','University of westminster',NULL,'harpreetsingh11200@gmail.com',''),(74,'ShamayitaDas,','','sam437457@gmail.com','student','University of Leeds',NULL,'sam437457@gmail.com',''),(75,'HimanshuVerma (Sagar Ref)','','hv754980@gmail.com','student','Coventry University',NULL,'hv754980@gmail.com',''),(76,'Rajni, Coventry University','','phougatrajni@gmail.com','student','Coventry University',NULL,'phougatrajni@gmail.com',''),(77,'Sadia','','sadiatayyab179@gmail.com','student','Liverpool john moores university',NULL,'sadiatayyab179@gmail.com',''),(78,'Amandeep','','amandeep19may1998@gmail.com','student','Leeds university',NULL,'amandeep19may1998@gmail.com',''),(79,'BhavyaVasannagari','','vasannagaribhavya25@gmail.com','student','university of portsmouth',NULL,'vasannagaribhavya25@gmail.com',''),(80,'ChiragBharda','','chiragbharda@gmail.com','student','Cardiﬀ Metropolitan University',NULL,'chiragbharda@gmail.com',''),(81,'SeemaSagar’s Ref Coventry','+44 7767 936575','seemaverma238@gmail.com','student','Coventry university',NULL,'seemaverma238@gmail.com',''),(82,'GurpinderSingh','+44 7741 988537','guridhanoa66565@gmail.com','student','Coventry university',NULL,'guridhanoa66565@gmail.com',''),(83,'ArjunSingh (Abhishek\'s Reference )','+44 7741 995795','arjun33241@gmail.com','student','Coventry university',NULL,'arjun33241@gmail.com',''),(84,'ShwetaGill','','shwetagumtali@gmail.com','student','Coventry university',NULL,'shwetagumtali@gmail.com',''),(85,'SagarGodiwala','','sagargodiwala111@gmail.com','student','Coventry university',NULL,'sagargodiwala111@gmail.com',''),(86,'SaiPindi','','indukurichaitanyavarma@gmail.com','student','University of Hertfordshire',NULL,'indukurichaitanyavarma@gmail.com',''),(87,'Mandeep','','mandeepschauhan2999@gmail.com','student','Nottingham Trent University',NULL,'mandeepschauhan2999@gmail.com',''),(88,'Sravani','','sravani.gumudavelly@gmail.com','student','University of Portsmouth',NULL,'sravani.gumudavelly@gmail.com',''),(89,'KamalpreetKamal','+44 7387 428145','kamalpreet29051989@gmail.com','student','University of Portsmouth',NULL,'kamalpreet29051989@gmail.com',''),(90,'GurmeetSandhu','+61 4 1598 6570','guriisandhu01@gmail.com','student','A Univ',NULL,'guriisandhu01@gmail.com',''),(91,'RamanKumar','','ramankumar28022004@gmail.com','student','Cardiﬀ Metropolitan University',NULL,'ramankumar28022004@gmail.com',''),(92,'JaspreetKaur','','jaspreetkaur34426@gmail.com','student','Wrexham glyndwr university',NULL,'jaspreetkaur34426@gmail.com',''),(93,'Hema(Harpreet\'s Ref bpp)','+44 7767 935359','dubeyhema987@gmail.com','student','BPP ',NULL,'dubeyhema987@gmail.com',''),(94,'AkashThapar (Parminder Ref BPP)','+44 7586 820575','akashthapar55@yahoo.com','student','BPP ',NULL,'akashthapar55@yahoo.com',''),(95,'NithyasreeRajesh (Sonia Ref BPP)','','nsreerajesh@gmail.com','student','BPP ',NULL,'nsreerajesh@gmail.com',''),(96,'DiljotKaur','','diljotkaur15@gmail.com','student','University Of Bedfordshire (Luton)',NULL,'diljotkaur15@gmail.com',''),(97,'MarrisOyiogu, Rajdeep Reference','','uchemarris@gmail.com','student','Porthsmouth',NULL,'uchemarris@gmail.com',''),(98,'IririJerry','','iririjerry@gmail.com','student','University of East Anglia',NULL,'iririjerry@gmail.com',''),(99,'NityaJose','','nityanj555@gmail.com','student','Leeds Beckett University',NULL,'nityanj555@gmail.com',''),(100,'Simran','','s22867390@gmail.com','student','De montfort University',NULL,'s22867390@gmail.com',''),(101,'kerstinjames','','kerstinjames10@gmail.com','student','Uni of Glos',NULL,'kerstinjames10@gmail.com',''),(102,'ShigilAshok','','shigil.ashok887@gmail.com','student','Leeds Beckett University',NULL,'shigil.ashok887@gmail.com',''),(103,'Jyotisharma','','jyotisharma6011@gmail.com','student','Leeds Beckett university',NULL,'jyotisharma6011@gmail.com',''),(104,'GiftyMonika','','giftymonika@gmail.com','student','Birmingham City University',NULL,'giftymonika@gmail.com',''),(105,'Mamta(Amandeep Reference)','+44 7909 229428','mamta2670128@gmail.com','student','Birmingham City University',NULL,'mamta2670128@gmail.com',''),(106,'Reshma','','anjureshma10@gmail.com','student','Leeds Beckett University',NULL,'anjureshma10@gmail.com',''),(107,'Parvinderkaur','','kparvinder2017@gmail.com','student','Birmingham City university',NULL,'kparvinder2017@gmail.com',''),(108,'PoojaRani, Sarb Reference BCU','','pd998810@gmail.com','student','BCU ',NULL,'pd998810@gmail.com',''),(109,'Sarb Dhilon Anmol Reference (BCU)','+44 7440 665865','sarbdhillon293@gmail.com','student','BIRMINGHAM CITY UNIVERSITY',NULL,'sarbdhillon293@gmail.com',''),(110,'DarshanMalik (Neeraj Ref)','+44 7796 816909','darshanmalik99@gmail.com','student','UNIVERSITY',NULL,'darshanmalik99@gmail.com',''),(111,'NeerajSaini Pulkit Ref UK','+44 7459 175835','sainineeraj14@yahoo.com','student','UNIVERSITY',NULL,'sainineeraj14@yahoo.com',''),(112,'Lavanya(RESHMA Reference)','','lavanya.jayabal2020@gmail.com','student','Leeds Beckett University',NULL,'lavanya.jayabal2020@gmail.com',''),(113,'Makwana Rakeshkumar','+1 ','rakeshmacwan520@gmail.com','student','BPP ',NULL,'rakeshmacwan520@gmail.com',''),(114,'Manpreet (Sagar\'s Ref. Coventry)','','mnpret56@gmail.com','student','Coventry',NULL,'mnpret56@gmail.com',''),(115,'Dimple kumari, Bpp','','virkdimple12345@gmail.com','student','Bpp ',NULL,'virkdimple12345@gmail.com',''),(116,'Soniya BPP','','soniyaakash236@gmail.com','student','Bpp ',NULL,'soniyaakash236@gmail.com',''),(117,'GOWTHAMANETTIKKAN','+1 ','gowthaman1717@gmail.com','student','Coventry',NULL,'gowthaman1717@gmail.com',''),(118,'Ankit Bangarh Neeraj Reference','+44 7747 205006','bangarh.a25@gmail.com','student','United Kingdom (UK)',NULL,'bangarh.a25@gmail.com',''),(119,'YousafMohammad(Ahsan Friend)','+1 ','yousaf.m1993@gmail.com','student','Northumbria university london',NULL,'yousaf.m1993@gmail.com',''),(120,'Balwindersingh, Bath Spa Uni','+1 ','buntysandhu197@gmail.com','student','Bath Spa Uni',NULL,'buntysandhu197@gmail.com',''),(121,'KanchanGoswami BPP','+1 ','kanchangoswami460@gmail.com','student','BPP ',NULL,'kanchangoswami460@gmail.com',''),(122,'ShivaniSouthern Cross University','+1 ','siratkaur847@gmail.com','student','Southern Cross University',NULL,'siratkaur847@gmail.com',''),(123,'krishashiroya, QUT','','krishashiroya1504@gmail.com','student','QUT Australia',NULL,'krishashiroya1504@gmail.com',''),(124,'Ankita M. Aulakh Vishal Reference','+61 4 8122 5661','ankitamehra1719@gmail.com','student','QUT Australia',NULL,'ankitamehra1719@gmail.com',''),(125,'Ramidi Saketh Reddy (Latrobe)','','ramidisaketh111@gmail.com','student','Latrobe university',NULL,'ramidisaketh111@gmail.com',''),(126,'Nidhi joshi Kaplan','+1 ','nidhijoshi1137@gmail.com','student','Kaplan business school',NULL,'nidhijoshi1137@gmail.com',''),(127,'Harpreet GillRaman Reference BPp','+44 7440 019865','gillharpreet464@gmail.com','student','BPP university',NULL,'gillharpreet464@gmail.com',''),(128,'Meenakshi (Latrobe)Anish','+61 4 2284 0030','meenakshianish02@gmail.com','student','La trobe University',NULL,'meenakshianish02@gmail.com',''),(129,'Shreya CoventrySethu','+44 7818 820802','shreyasethu@gmail.com','student','Coventry',NULL,'shreyasethu@gmail.com',''),(130,'RAJA PRAKASAM','+44 ','raja.prakasah17121995@gmail.com','student','Coventry',NULL,'raja.prakasah17121995@gmail.com',''),(131,'Harmandeep kaur (Torrens)','+61 4 5080 9691','hkdeep89@gmail.com','student','Torrens',NULL,'hkdeep89@gmail.com',''),(132,'Samreena Mustafa BPP','+44 ','samreenamustafa.nasa5@gmail.com','student','BPP ',NULL,'samreenamustafa.nasa5@gmail.com',''),(133,' MounikaChalamala Coventry','+44 7741 797160','mounikachalamala1533@gmail.com','student','Coventry',NULL,'mounikachalamala1533@gmail.com',''),(134,'RajdeepPortsmouth University','+44 7341 700443','rajdeep230141@yahoo.com','student','Portsmouth',NULL,'rajdeep230141@yahoo.com',''),(135,'GunjanAgarwal','+91 88715-87546','agarwalgunjan0211@gmail.com','vendor',NULL,'Gunjan ',NULL,NULL),(136,'SahajpalLondon school of management education','+44 7405 241544','sahajtatla@gmail.com','student','London school of management education',NULL,'sahajtatla@gmail.com',''),(137,'Manjinder singh (Bedfordshire)','+44 ','sunnydhillon774@gmail.com','student','Bedfordshire',NULL,'sunnydhillon774@gmail.com',''),(138,'KirandeepkaurBPP','+91 98727-63145','Kiransaini5393@gmail.com','student','BPP ',NULL,'Kiransaini5393@gmail.com',''),(139,'Nalin Raj Leicester','+44 7436 785018','nalinraj12585@gmail.com','student','University of Leicester',NULL,'nalinraj12585@gmail.com',''),(140,'Davinder kaur BPP','+1 ','santbir22gill@gmail.com','student','BPP ',NULL,'santbir22gill@gmail.com',''),(141,' AndrewFeby LaTrobe','+1 ','andrew.a.feby@gmail.com','student','Latrobe',NULL,'andrew.a.feby@gmail.com',''),(142,'Jashanjot Singh, BPP','+44 ','Jashanjotsingh1998@gmail.com','student','BPP ',NULL,'Jashanjotsingh1998@gmail.com',''),(143,'SimranBPP ','+44 ','siimmzzrajjput@gmail.com','student','BPP ',NULL,'siimmzzrajjput@gmail.com',''),(144,'Sidra Arshad BPP','+44 7362 458753','sidraarshad.elite@gmail.com','student','BPP ',NULL,'sidraarshad.elite@gmail.com',''),(145,'Jyoti Kelpen University','','J03391141@gmail.com','student','Keplen University',NULL,'J03391141@gmail.com',''),(146,'teststudent','+1 ','teststudent@gmail.com','student','Some University',NULL,'teststudent@gmail.com',''),(147,'test001','+1 ','test001@gmail.com','student','BPP ',NULL,'test001@gmail.com','');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `contact` varchar(25) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `roles` varchar(45) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_employees_1_idx` (`employee_id`),
  CONSTRAINT `fk_employees_1` FOREIGN KEY (`employee_id`) REFERENCES `users` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (8,35,'hr','hr','hr@gmail.com','',NULL,NULL,'full','hr',NULL),(18,45,'Prateek','Sharma','prateek@gmail.com',NULL,NULL,'','permanent','expert',NULL),(19,46,'Simran','Sharma','simran@gmail.com',NULL,NULL,'','permanent','lead',NULL),(44,71,'test','lead1','testlead1@gmail.com',NULL,NULL,'+1 ','permanent','lead',NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orders_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `invoice_number` varchar(45) DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `tax_type` varchar(45) DEFAULT NULL,
  `currency` varchar(45) DEFAULT NULL,
  `dis_percent` float DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `sub_tax` varchar(20) DEFAULT NULL,
  `paid_amount` float DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `discountType` varchar(45) DEFAULT NULL,
  `tax_amount` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `tax_rate` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index2` (`client_id`),
  CONSTRAINT `fk_invoice_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (173,NULL,'TH-4514',56,0,'2024-02-26','2024-02-26','','GBP',0,500,'',120,'2024-02-26','','',0,500,0),(177,NULL,'TH-2616',57,0,'2024-02-26','2024-02-27','','GBP',0,150,'',150,'2024-02-26','','',0,150,0),(179,NULL,'TH-1207',58,0,'2024-02-26','2024-02-27','','AUD',0,300,'',0,NULL,NULL,'',0,300,0),(180,NULL,'TH-2616',57,0,'2024-02-26','2024-02-27',NULL,'GBP',0,30,NULL,150,'2024-02-26','',NULL,0,30,0),(181,NULL,'TH-2752',64,0,'2024-02-26','2024-02-27','','AUD',0,362,'',362,'2024-02-26','','',0,362,0),(182,NULL,'TH-7137',65,0,'2024-02-26','2024-02-27','','INR',0,6250,'',0,NULL,NULL,'',0,6250,0),(186,NULL,'TH-3693',57,0,'2024-02-27','2024-02-28','','USD',0,12,'',0,NULL,NULL,'',0,12,0),(187,NULL,'TH-4514',56,0,'2024-02-26','2024-02-26',NULL,'GBP',0,500,NULL,NULL,NULL,NULL,NULL,0,500,0);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_orders`
--

DROP TABLE IF EXISTS `invoice_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(45) DEFAULT NULL,
  `orders_id` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `vat` float DEFAULT NULL,
  `cgst` float DEFAULT NULL,
  `igst` float DEFAULT NULL,
  `sgst` float DEFAULT NULL,
  `item` varchar(45) DEFAULT NULL,
  `item_total` float DEFAULT NULL,
  `tax_rate` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_orders`
--

LOCK TABLES `invoice_orders` WRITE;
/*!40000 ALTER TABLE `invoice_orders` DISABLE KEYS */;
INSERT INTO `invoice_orders` VALUES (4,'TH-4514','TH00727,',500,500,1,0,0,0,0,'Data Analysis',500,0),(12,'TH-2616','TH00854',30,30,1,0,0,0,0,'Data Science',30,0),(15,'TH-1207','TEST12',120,120,1,0,0,0,0,'TEST',120,0),(16,'TH-1207','TH00839',180,180,1,0,0,0,0,'Data Science',180,0),(17,'TH-2616','Test01',120,120,1,0,0,0,0,'Test',120,0),(18,'TH-2752','TEST123',120,120,1,0,0,0,0,'TEST3',120,0),(19,'TH-7137','001',6250,6250,1,0,0,0,0,'English',6250,0),(21,'TH-2752','Test-001',122,122,1,0,0,0,0,'sub test',122,0),(22,'TH-2752','Test-004',120,120,1,0,0,0,0,'Test',120,0),(24,'TH-3693','Test02',12,12,1,0,0,0,0,'Test',12,0),(26,'TH-4514','new-001',0,0,1,0,0,0,0,'test',0,0);
/*!40000 ALTER TABLE `invoice_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `orders_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Task_Subject` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Expert_id` int DEFAULT NULL,
  `Client_id` int NOT NULL,
  `Status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Start_date` date NOT NULL,
  `End_date` date NOT NULL,
  `order_budget` float DEFAULT NULL,
  `currency` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Qc_Expert_id` int DEFAULT NULL,
  `Otm_id` int DEFAULT NULL,
  `Description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Word_count` int DEFAULT NULL,
  `Expert_price` int DEFAULT NULL,
  `task_date` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `expert_currency` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `expert_deadline` date DEFAULT NULL,
  `assigned_expert` int DEFAULT NULL,
  `assigned_expert_deadline` date DEFAULT NULL,
  PRIMARY KEY (`orders_id`),
  KEY `fk_expert_id_idx` (`Expert_id`),
  KEY `fk_expert_2_idx` (`Qc_Expert_id`),
  KEY `fk_client_id` (`Client_id`),
  KEY `fk_otm` (`Otm_id`),
  CONSTRAINT `fk_client_id` FOREIGN KEY (`Client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_expert_2` FOREIGN KEY (`Qc_Expert_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_expert_id` FOREIGN KEY (`Expert_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_otm` FOREIGN KEY (`Otm_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('001','English',NULL,65,'assigned','2023-12-23','2023-12-31',6250,'INR',NULL,NULL,'palak task new 001 aa',1500,0,'2023-12-23',NULL,NULL,NULL,NULL),('002','English',NULL,65,'assigned','2023-12-23','2023-12-31',6250,'INR',NULL,NULL,'palak task 002 bhrdrs',1500,0,'2023-12-23',NULL,NULL,NULL,NULL),('new-001','test',NULL,56,'assigned','2024-03-19','2024-03-22',NULL,NULL,NULL,NULL,'',0,0,'2024-03-19','',NULL,NULL,NULL),('Test-001','sub test',NULL,64,'assigned','2024-02-26','2024-02-26',NULL,NULL,NULL,NULL,'',0,0,'2024-02-26','',NULL,NULL,NULL),('Test-004','Test',NULL,64,'assigned','2024-02-26','2024-02-26',NULL,NULL,NULL,NULL,'',0,0,'2024-02-26','',NULL,NULL,NULL),('Test-009','Test',NULL,64,'new order','2024-02-26','2024-02-26',NULL,NULL,NULL,NULL,'',0,0,'2024-02-26','',NULL,NULL,NULL),('Test01','Test',NULL,57,'new order','2024-02-26','2024-02-26',NULL,NULL,NULL,NULL,'',0,0,'2024-02-26','',NULL,NULL,NULL),('Test02','Test',NULL,57,'new order','2024-02-26','2024-02-26',NULL,NULL,NULL,NULL,'',0,0,'2024-02-26','',NULL,NULL,NULL),('TEST12','TEST',NULL,58,'new order','2024-02-10','2024-02-10',NULL,NULL,NULL,NULL,'TEST',1212,0,'2024-02-10','',NULL,NULL,NULL),('TEST123','TEST3',NULL,64,'new order','2024-02-09','2024-02-09',0,'null',NULL,NULL,'TEST',2333,0,'2024-02-09','',NULL,NULL,NULL),('TH-009000','Test Sub',NULL,64,'new order','2024-02-27','2024-02-27',NULL,NULL,NULL,NULL,'',0,0,'2024-02-27','',NULL,NULL,NULL),('TH00727,','Data Analysis',NULL,56,'new order','2023-12-23','2024-01-20',500,'GBP',NULL,NULL,'',1200,0,'2023-12-23',NULL,NULL,NULL,NULL),('TH00817','DBMS',NULL,63,'new order','2023-12-23','2024-01-06',120,'GBP',NULL,NULL,'',1000,0,'2023-12-23',NULL,NULL,NULL,NULL),('TH00835','Database',NULL,61,'new order','2023-12-23','2024-01-06',60,'GBP',NULL,NULL,'',1900,0,'2023-12-23',NULL,NULL,NULL,NULL),('TH00839','Data Science',NULL,58,'new order','2023-12-23','2024-01-06',180,'GBP',NULL,NULL,'',1600,0,'2023-12-23',NULL,NULL,NULL,NULL),('TH00854','Data Science',NULL,57,'new order','2023-12-23','2024-01-27',30,'GBP',NULL,NULL,'',1900,0,'2023-12-23',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `users_id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contact` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `joiningDate` date NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','admin','admin','0','2023-01-11','admin'),(35,'hr','hr','123456','hr@gmail.com','4565656789','2023-08-08','hr'),(45,'Prateek','Sharma','123456','prateek@gmail.com','','2023-12-23','expert'),(46,'Simran','Sharma','123456','simran@gmail.com','','2023-12-23','lead'),(71,'test','lead1','123456','testlead1@gmail.com','+1 ','2024-02-27','lead');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-11 15:02:23
